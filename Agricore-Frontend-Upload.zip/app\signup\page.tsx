export default function SignupPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-emerald-50 to-white">
      <div className="mx-auto flex min-h-screen max-w-6xl items-center justify-center px-6 py-16">

        <div className="grid w-full gap-12 lg:grid-cols-2">

          <div className="flex flex-col justify-center">

            <div className="inline-flex h-14 w-14 items-center justify-center rounded-xl bg-emerald-700 text-2xl font-bold text-white">
              AC
            </div>

            <h1 className="mt-8 text-5xl font-bold tracking-tight">
              Run your agricultural engineering business with AgriCore.
            </h1>

            <p className="mt-6 text-lg text-gray-600">
              Jobs, customers, machines, service schedules,
              technician management, invoicing and AI diagnostics —
              all in one platform.
            </p>

            <ul className="mt-10 space-y-4 text-lg">
              <li>✔ Unlimited job cards</li>
              <li>✔ Customer & machine history</li>
              <li>✔ Technician mobile app</li>
              <li>✔ Offline working</li>
              <li>✔ AI diagnostics</li>
              <li>✔ 14-day free trial</li>
            </ul>

          </div>

          <div className="rounded-3xl bg-white p-10 shadow-xl">

            <h2 className="text-3xl font-bold">
              Start your free trial
            </h2>

            <p className="mt-2 text-gray-500">
              No card required.
            </p>

            <form className="mt-8 space-y-5">

              <input
                className="w-full rounded-xl border p-4"
                placeholder="Company Name"
              />

              <input
                className="w-full rounded-xl border p-4"
                placeholder="Your Name"
              />

              <input
                className="w-full rounded-xl border p-4"
                placeholder="Email"
              />

              <input
                type="password"
                className="w-full rounded-xl border p-4"
                placeholder="Password"
              />

              <button
                className="w-full rounded-xl bg-emerald-700 py-4 text-lg font-semibold text-white"
              >
                Start Free Trial
              </button>

            </form>

          </div>

        </div>

      </div>
    </main>
  );
}